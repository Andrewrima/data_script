﻿## Script para inicar a replicação e suspender a replicação do Storage Replica. - Créditos Gabriel Luiz - www.gabrielluiz.com ##

Sync-SRGroup -Name "REPLICA-SR2" # Inicia a replicação do Storage Replica.

Suspend-SRGroup -Name "REPLICA-SR2" # Suspende a replicação do Storage Replica.