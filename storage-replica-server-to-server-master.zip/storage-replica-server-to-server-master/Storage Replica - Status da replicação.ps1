﻿## Script para status da replicação. - Créditos Gabriel Luiz - www.gabrielluiz.com ##

Get-SRGroup
Get-SRPartnership  
(Get-SRGroup).replicas